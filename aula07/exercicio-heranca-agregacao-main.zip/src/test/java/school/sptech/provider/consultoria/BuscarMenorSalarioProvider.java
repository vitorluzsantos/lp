package school.sptech.provider.consultoria;

import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;
import school.sptech.factory.DesenvolvedorMobileFactory;
import school.sptech.factory.DesenvolvedorWebFactory;

import java.util.List;
import java.util.stream.Stream;

import static school.sptech.factory.DesenvolvedorFactory.build;

public class BuscarMenorSalarioProvider implements ArgumentsProvider {

  @Override
  public Stream<? extends Arguments> provideArguments(ExtensionContext extensionContext) throws Exception {
    Object d1 = build("Paulo", 32, 58.7);
    Object d2 = build("Lívia", 47, 67.3);
    Object d3 = build("Elisa", 34, 45.2);
    Object d4 = build("Yasmin", 45, 49.8);
    Object d5 = build("Tiago", 40, 64.4);

    Object d6 = DesenvolvedorWebFactory.build("Bianca", 32, 68.7, "React", "Django", "PostgreSQL", 12);
    Object d7 = DesenvolvedorWebFactory.build("Enzo", 47, 65.2, "Vue", "Express", "MySQL", 18);
    Object d8 = DesenvolvedorWebFactory.build("Mariana", 34, 52.8, "Angular", "Rails", "MongoDB", 15);
    Object d9 = DesenvolvedorWebFactory.build("Gustavo", 45, 59.5, "Svelte", "Flask", "Oracle", 13);
    Object d10 = DesenvolvedorWebFactory.build("Sofia", 40, 61.3, "Ember", "Laravel", "SQL Server", 16);

    Object d11 = DesenvolvedorMobileFactory.build("Leonardo", 50, 44.7, "iOS", "Swift", 10);
    Object d12 = DesenvolvedorMobileFactory.build("Valentina", 30, 67.4, "Android", "Java", 19);
    Object d13 = DesenvolvedorMobileFactory.build("Joaquim", 37, 52.9, "iOS", "Swift", 14);
    Object d14 = DesenvolvedorMobileFactory.build("Alice", 42, 46.5, "Android", "Kotlin", 11);
    Object d15 = DesenvolvedorMobileFactory.build("Rafael", 39, 68.1, "iOS", "Swift", 17);

    return Stream.of(
        Arguments.of("Consultoria vazia deve retornar null", "Consultoria 1", 10, List.of(), null),
        Arguments.of("Menor salário entre desenvolvedores comuns", "Consultoria 1", 10, List.of(d1, d2, d3, d4, d5), d3),
        Arguments.of("Menor salário entre desenvolvedores web (o menor é o primeiro da lista)", "Consultoria 2", 10, List.of(d6, d7, d8, d9, d10), d6),
        Arguments.of("Menor salário entre desenvolvedores mobile", "Consultoria 3", 10, List.of(d11, d12, d13, d14, d15), d14),
        Arguments.of("Menor salário com tipos misturados (o menor é o primeiro da lista)", "Consultoria 4", 10, List.of(d1, d6, d7, d11, d12), d1),
        Arguments.of("Menor salário com um desenvolvedor de cada tipo (o menor é o primeiro da lista)", "Consultoria 5", 10, List.of(d5, d10, d15), d5),
        Arguments.of("Menor salário com tipos misturados (o menor é o último da lista)", "Consultoria 7", 10, List.of(d2, d7, d12, d3), d3),
        Arguments.of("Consultoria com apenas um desenvolvedor deve retorná-lo", "Consultoria 8", 10, List.of(d7), d7)
    );
  }
}
